<?php

        //Se houver uma requisição do tipo POST, isso quer dizer que eu quero editar os dados do usuário ou contato. Vamos pegar o nome e o e-mail, atualizar o registro e retornar para a página inicial. Ou seja, tem consequência.

    include 'database.php';

    $id = intval($_GET['id']); //Garantir q o ID seja um Inteiro

        //Nos buscavamos os dados do usuario e montravamos no formulario de edicao

    $currentUser = buscarUsuarioPorId($id);



//agora precisamos editalos

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['nome']) && isset($_POST['email'])) 
    {

        $nome = $_POST['nome'];
        $email = $_POST['email'];


        atualizarUsuario($id, $nome, $email); //mas nao é pra atualizar o id, to confusa


          header('Location: index.php');
           exit;
    }
   }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário</title>
    <link rel="stylesheet" href="estilo.css">
</head>

<body>
    <h1>Editar Usuário</h1>

    <form action="edit.php?id=<?php echo $id ?>" method="post">
        <label for="nome">Nome: </label>
        <input type="text" name="nome" id="nome" required value="<?php echo $currentUser['nome'] ?>">

        <label for="email">Email: </label>
        <input type="email" name="email" id="email" required value="<?php echo $currentUser['email'] ?>">

        <input type="submit" value="Atualizar Usuário">
    </form>

</body>

</html>