<?php

include 'database.php';
//Pegar os dados do formulario


$nome = $_POST['nome']; //q q eu tenho q mudar o n ou o nome
$email = $_POST['email'];

inserirUsuario($nome, $email);

//redireciona pra pagina principal
header('Location: index.php');
exit;