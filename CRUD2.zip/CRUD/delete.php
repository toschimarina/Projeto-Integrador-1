<?php

include 'database.php';

$id = $_GET["id"];

//Quero remover o usuário que tenha o id passado como parametro
deletarUsuario( $id );

header('Location: index.php');
exit;