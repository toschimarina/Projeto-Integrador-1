<!DOCTYPE html>
<html lang="pt-br">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <title>Introdução ao PHP</title>
</head>


<body>
    <h1>Introdução ao PHP com CRUD (Create, Update, Delete). Vamos usar uma sessão com banco de dados MYSQL para nossas operações.</h1>


    <p>É uma linguagem que nos permite criar páginas web de maneira rápida e simplificada. O PHP é uma das linguagens
        mais utilizadas no desenvolvimento web. Esse exercício é um CRUD com o uso de sessão no PHP.</p>


    <h2>Adicionar novo Usuário</h2>
    <form action="create.php" method="post">


        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" required> <!-- Diferença de ID e Name? -->


        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>


        <input type="submit" value="Adicionar Usuário">
    </form>


    <h2>Lista de Usuários</h2>


    <table>
        <thead>
            <tr>
            </tr>
        </thead>
        <tbody>
            <tr>
            <?php
                include 'database.php';


                $conn = conectarBancoDeDados();
                $result = buscarTodosUsuarios($conn);

                if ($result->num_rows > 0):
                    while ($user = $result->fetch_assoc()):
            ?>
                <td><?php echo htmlspecialchars($user['id']); ?></td>
                <td><?php echo htmlspecialchars($user['nome']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $user['id']; ?> " class="edit-btn"> Editar</a>
                    <a href="delete.php?id=<?php echo $user['id']; ?> " class="delete-btn"> Excluir</a>
                </td>
            </tr>
            <?php 
                endwhile;
                else:
            ?>
            <tr>
                <td colspan="4">Nenhum usuário encontrado</td>
            </tr>
            <?php
            endif;
            $conn ->close();
            ?>

        </tbody>
    </table>


</body>


</html>