<?php

function conectarBancoDeDados() {
    $conn = new mysqli('localhost','root', '','crud',);

    if ($conn->connect_error) {
        die("Falha na conexão! O erro foi: ". $conn->connect_error);
    }

    return $conn;

}

function buscarTodosUsuarios($conn) {
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    return $result;   
}

function buscarUsuarioPorId($id){
    $conn = conectarBancoDeDados();

    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);

    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    $stmt->close();
    $conn->close();

    return $usuario;
}


function inserirUsuario($nome, $email) {
    $conn = conectarBancoDeDados();

    //Preparar a nossa instrução SQL que vai fazer a inserção de modo a evitar SQL Injection
   $stmt = $conn->prepare(query: "INSERT INTO users(nome, email) VALUES(?, ?)");
   $stmt->bind_param("ss", $nome, $email);

   $stmt->execute();
   $stmt->close();
}

function deletarUsuario($id){
    $conn = conectarBancoDeDados();

    //preparar a instrução para evitar SQL Injection por segurança
    $stmt = $conn->prepare(query:"DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);

    $stmt->execute();
    $stmt->close();
    $conn->close();
}


function atualizarUsuario($id, $nome, $email) {
    $conn = conectarBancoDeDados();

    //preparar a instrução de segurança
    $stmt = $conn->prepare("UPDATE users SET nome = ?, email = ? WHERE id = ?");  //pq name e nao nome?
    $stmt->bind_param("ssi", $nome, $email, $id);

    $stmt->execute();

    $stmt->close();
    $conn->close();
}

?>