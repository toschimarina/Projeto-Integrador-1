<?php

session_start();

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <title>Introdução ao PHP</title>
</head>

<body>
    <h1>Introdução ao PHP com CRUD (Create, Update, Delete). Vamos usar uma sessão com banco de dados simulado.</h1>

    <p>É uma linguagem que nos permite criar páginas web de maneira rápida e simplificada. O PHP é uma das linguagens
        mais utilizadas no desenvolvimento web. Esse exercício é um CRUD com o uso de sessão no PHP.</p>

    <h2>Adicionar novo Usuário</h2>
    <!-- Existe alguns tipos de requisições. Os mais comuns são GET e POST. 
    Quando o cliente faz uma requisição do tipo GET ele quer buscar algo do servidor (consultar lista de contatos). 
    Quando o cliente quer submeter um conjunto de dados, formulários ou fazer uma ação que gere um efeito colateral, usamos requisições do tipo POST, como, por exemplo, deletar, fazer login ou adicionar. -->

    <form action="create.php" method="post">

        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" required> <!-- Diferença de ID e Name? -->

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <input type="submit" value="Adicionar Usuário">
    </form>

    <h2>Lista de Usuários</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Ações</th>
            </tr>
        </thead>
        <!-- Mostrar os elementos (os usuários cadastrados).
                Como? 
            Primeiro, vou verificar se existe algum usuário cadastrado. 
                *Caso sim, mostro os usuários por meio de uma estrutura de repetição, cada usuário será exibido em uma linha da tabela.
                *Agora, caso não exista nenhum usuário cadastrado, mostro uma mensagem informando que não há usuários cadastrados. -->

        <tbody>
            <?php if (!empty($_SESSION['users'])): ?>
                <?php foreach ($_SESSION['users'] as $user): ?>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo $user['nome']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td>
                        <a href="edit.php?id=<?php echo $user['id']; ?> " class="edit-btn"> Editar</a>
                        <a href="delete.php?id=<?php echo $user['id']; ?> " class="delete-btn"> Excluir</a>
                    </td>
                </tbody>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">Nenhum usuário encontrado</td>
            </tr>
        <?php endif; ?>
    </table>
    <!-- Quais são os próximos passos?
            Começar a fazer o PHP funcionalidade por funcionalidade:
                *Começar pelo criar
                *Visualizar
                *Deletar
                *Por último, editar
                *Também preciso do CSS! -->
</body>

</html>