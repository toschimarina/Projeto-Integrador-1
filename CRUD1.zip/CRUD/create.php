<?php

// eu vou usar sessão como banco de dados simulado

session_start();
//Pegar os dados do formulario


$nome = $_POST['nome']; //q q eu tenho q mudar o n ou o nome
$email = $_POST['email'];


//função para gerar id
$id = gerarId();

$_SESSION['users'][] = [
    'id' => $id,
    'nome' => $nome,
    'email' => $email,
];



//como q vamos gerar esse ID?
//primeiro caso: nao existe ninguem cadastrado, entrao primeiro id deve ser 1
//segundo caso: ja exite alguem cadastrado, então o id tem q ser id anterior + 1
function gerarId()
{
    if (empty($_SESSION['users'])) {
        return 1;
    } else {
        $ultimoUsuarioCadastrado = end($_SESSION['users']);
        return $ultimoUsuarioCadastrado['id'] + 1;
    }
}

//redireciona pra pagina principal
header('Location: index.php');
exit;