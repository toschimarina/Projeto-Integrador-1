<?php
//Se houver uma requisição do tipo POST, isso quer dizer que eu quero editar os dados do usuário ou contato. Vamos pegar o nome e o e-mail, atualizar o registro e retornar para a página inicial. Ou seja, tem consequência.
session_start();

$id = $_GET['id'];

foreach ($_SESSION['users'] as $user) {
    if ($user['id'] == $id) {
        $currentUser = $user;
        break;
    }

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_SESSION['users'] as $key => $user) {
        if ($user['id'] == $id) {
            $_SESSION['users'][$key]['nome'] = $_POST['nome'];
            $_SESSION['users'][$key]['email'] = $_POST['email'];

            header('Location: index.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário</title>
    <link rel="stylesheet" href="estilo.css">
</head>

<body>
    <h1>Editar Usuário</h1>

    <form action="edit.php?id=<?php echo $id ?>" method="post">
        <label for="nome">Nome: </label>
        <input type="text" name="nome" id="nome" required value="<?php echo $currentUser['nome'] ?>">

        <label for="email">Email: </label>
        <input type="email" name="email" id="email" required value="<?php echo $currentUser['email'] ?>">

        <input type="submit" value="Atualizar Usuário">
    </form>

</body>

</html>